

const domContainer = document.querySelector('#select_container');
const root = ReactDOM.createRoot(domContainer);
root.render(e(LikeButton));