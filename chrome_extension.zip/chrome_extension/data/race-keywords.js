export const asianKw = ["azn",

"banana",

"bananame",

"bandwidth nigger/whore",

"bed time",

"bruce lee",

"bruised banana",

"buddhahead",

"bug-eater",

"bukkakese",

"burnt rice",

"can'ardly",

"chap",

"chinaman",

"ching-chong",

"chinina",

"chink",

"chinkerbell",

"coin slot",

"cook",

"coolie",

"data",

"dog-eater",

"dog-muncher",

"dwo",

"egghead",

"eggroll",

"fingernail rancher",

"fishhead",

"floss",

"gink",

"goldfish monger",

"goloid",

"gookemon",

"grasshopper",

"grinder",

"hab",

"honky/honkie",

"ironing board",

"japanigger",

"jaundy boy",

"jin",

"link",
"junta",

"knees",

"lego",

"lemonhead",

"little hiroshima",

"meat pie",

"miyagi",

"mushu",

"ng",

"nikon",

"nine iron",

"ninja",

"nuprin",

"oreo",

"ornamental",

"p-1",

"pancake",

"panhead",

"patty",

"peeled banana",

"pineapple lump",

"ping-pang",

"pizdaglaz",

"plate tossers",

"pointy-head",

"post it",

"potato queen",

"powerpoint",

"protractor",

"pumpkinhead",

"quarter jockey",

"raisin",

"random",

"rangoon",

"rasian",

"rice ball",

"rice burner/rice rocket",

"rice nigger",

"rice-cooker",

"rice-eater",

"rice-paddy",

"rice-picker",

"sbh",

"schlitzauge",

"seaweed-sucker",

"simpson",

"slant",

"slantey-eye'd",

"sleepwalker",

"slit",

"slope",

"slope head",

"smack",

"socket face",

"soy sauce",

"soyback",

"squint",

"sunny side up",

"tab",

"table face",

"tai-chink",

"tape head",

"taxi",

"test-taker",

"thin-eyed",

"tinty",

"tiny",

"triad",

"twinkie",

"two stroke",

"ufo",

"uzbek",

"vc",

"wang chung",

"waverunner",

"widescreen",

"winky",

"wog",

"woggle",

"yangmo",

"yao",

"yellow",

"yellow devil",

"yellow monkey",

"yelvis",

"yigger",

"yolk",

"zip",

"zipperhead",
]

export const blackKw = ["925",

"aa",

"abeed",

"ace of spades",

"african",

"african't",

"africoon",

"afro",

"americoon",

"angus",

"antique farm equipment",

"ape",

"apple",

"arf",

"ashy",

"aunt jemima",

"baboomba",

"baboon",

"baluba",

"baluga",

"banjo lips",

"bantu",

"bap",

"bbk",

"bdn",

"bear",

"bebe's kids",

"beggar",

"bergie",

"bet",

"bfi",

"billy reuben",

"bingo-bongo",

"biscuit lip",

"bix nood",

"black barbie",

"black magic",

"black time",

"blackie",

"blacky chan",

"bleck",

"http://imdb.com/title/tt0097733/",
"blockbuster",

"blood",

"blow",

"blt",

"blue gums",

"bmw",

"bo-bo",

"bobblehead",

"boffer/boofer",

"bomb",

"bonky",

"boogat",

"boogie",

"boon",

"bootlip",

"bounty bar",

"bourbon",

"boy",

"bozak",

"branch manager",

"brillo pad",

"bro",

"brother",

"brown trumpet",

"brownie",

"bubb rubb",

"bubba",

"bubbles",

"buck/buck nigger",

"buckwheat",

"buffalo soldier",

"bumper lips",

"bun",

"buppie",

"burnt cracker",

"burnt match",

"burnt toast",

"burr head",

"bush-boogie",

"butter",

"c-15",

"caffre",

"calpurnia",

"camel lips",

"canadian",

"candy man",

"canigger",

"cargo",

"carl winslow",

"carlton (banks)",

"casabooboo",

"cast iron",

"chad",

"chain dragger",

"chalky",

"chango",

"charcoal briquette",

"chernozhopyi",

"here",
"cheshire cat",

"chicago navajo",

"chicken bandit",

"chiquita",

"choco",

"chocolate drop",

"chocolate-covered marshmallow",

"chombo",

"chud",

"clicky",

"cliff ape",

"clocker",

"clyde",

"coal-miner",

"cocoa",

"cocoa puff",

"cocolo",

"coconut",

"cocoon",

"cold drink",

"colin",

"colonel's kids",

"colored",

"coltrane",

"congo",

"congo lip",

"conky",

"conquistador",

"convict",

"cookie",

"coon",

"coonadian",

"cooner",

"coontang",

"cordon",

"cornbread",

"cornelius",

"cosby",

"cotton ball",

"cotton-picker",

"craw",

"crayola",

"cream of wheat",

"cricket",

"crime",

"crimestopper",

"criminal factory",

"crioulo",

"crispy",

"crow",

"jim crow laws",
"cubs",

"cuff",

"curb-biter",

"czarnuch",

"d.f.n.",

"dan",

"darkie",

"darkness",

"dawg",

"defendant",

"democrats",

"destro",

"deuce",

"ding dong",

"dinge",

"do-da",

"donkey kong",

"dootie",

"dorito",

"double a",

"double dip",

"doujin",

"dwb",

"egglet",

"eggot",

"eggplant",

"egot",

"egoy",

"eight ball",

"elevator operator",

"eraser head",

"es-obe",

"extra crispy",

"fahim",

"fakey jamaikey",

"fat albert",

"feargal",

"feb",

"field nigger",

"fila",

"floppy",

"foedy",

"franklin",

"frasier",

"frobro",

"frostbite",

"fubu",

"future inmate",

"g/gee",

"gar",

"gatorbait",

"ged",

"geechee",

"gullah",
"ghetto",

"ghetto hamster",

"ghetto monkey",

"ghost rider",

"gimpy",

"glocky",

"golliwog",

"gor",

"gorilla",

"grapico",

"greaser",

"gro",

"groid",

"gronesha",

"gta",

"guttermonkey",

"hagwei/hayquay",

"hakui",

"half-human",

"hambone",

"harlem",

"haunt",

"hendrix",

"high yellow",

"hnic",

"ho baas",

"ho de doz",

"holy shit",

"homey/homie",

"hoopty",

"hootie",

"horse-gums",

"hotel",

"hotnot",

"house nigger",

"huey",

"hutch",

"huxtable",

"i p's",

"inky",

"j.j.",

"jackamammy",

"jackpot",

"jambo",

"jar jar",

"jellybean",

"jerry curl",

"jersey-dweller",

"jet",

"jiffy pop",

"jig",

"jig and a pig",

"jigaboo",

"jigga",

"jim",

"jim crow",

"here",
"jr. mint",

"juba",

"july ham",

"june bug",

"jungle bunny",

"justin igger",

"kaffer/ir",

"kaffir",

"kala",

"kfc",

"kingfish",

"kirby",

"kizzy",

"knees grow",

"knuckle-dragger",

"kobe",

"koku-jin",

"koolaid",

"kooshi",

"kunta (kinte)",

"kurochan",

"kurombo",

"kushi",

"lando",

"latifah",

"lawn jockey",

"leprecoon",

"leroy",

"leroy rogers",

"levar",

"lincoln's mistake",

"little (black) sambo",

"liver lips",

"liverlips",

"lucius",

"lugz",

"ma se poes",

"magila gorilla",

"mammy",

"mandingo",

"movie",
"mandinka",

"mangro-monkey",

"maroon",

"marta",

"mavro/mav",

"mayate",

"mcnigga",

"mechanical",

"melanzana",

"mellanoid",

"melon johnny",

"meshky",

"mi dang",

"midnight",

"milk dud",

"milkman",

"mishwa",

"miss cleo",

"missippi tree emblem",

"mississippi blue lip",

"miyate",

"mlk",

"mo and yo",

"moanback",

"monday",

"monkey",

"monkeyboy",

"mono",

"montu",

"mooliachi",

"moolie",

"moolignon",

"moon cricket",

"mottisa",

"mow-mow",

"mr. big",

"mr. bojangles",

"muckadoo",

"mud duck",

"mud flaps",

"mud people",

"mud turtle",

"mufasa",

"muffin-head",

"mulunyan",

"munt",

"n'er",

"naca",

"naga",

"nagur",

"naha",

"nanner",

"napa",

"nappy head",

"nappy-headed ho",

"neekeri/nekru",

"negative",

"negress",

"negro",

"negroid",

"nelly",

"nft",

"ni-ni",

"niche",

"nig-nog",

"niggabyte",

"niggapotomous",

"nigger",

"some interesting history",
"nigger mortis",

"niggerachi",

"niggerette",

"niggerino",

"niggeroid",

"nigglet",

"nightcrawler",

"niglige",

"nigloo",

"nignorant",

"nigonometry",

"nigra",

"nigress",

"niknok",

"nineteens (19's)",

"ninja",

"nitch",

"nog",

"nola",

"nonswimmer",

"nooc",

"november",

"nubian princess",

"number 2",

"nurple",

"o.j.",

"o.t.w.",

"oar tuggers",

"obg",

"oil slick",

"old brown tucker",

"omarosa",

"orb",

"oreo",

"orlando",

"othello",

"p.o.a.",

"palta",

"papolo",

"patio primate",

"pez dispenser",

"pickaninny",

"pine sol",

"pine tree ornament",

"pineapple",

"pink-heel",

"pit",

"platneus",

"plow jockey",

"poc",

"point-six (.6)",

"pontiac",

"poo",

"pookie",

"popolo",

"porch monkey",

"prapper",

"pretzel",

"prieto",

"primate",

"property",

"pube head",

"pubie",

"puddle duck",

"pusher-man",

"quashee",

"ragoona",

"raisinhead",

"re-nigg",

"redbone",

"link",
"reggie",

"reggin",

"reggina",

"remote control",

"roach",

"rock",

"rockfish",

"roid",

"rope-head",

"rope-straightener",

"royal hawaiian",

"rufus",

"runs, the",

"safe",

"sailor",

"sambo",

"san",

"sanford",

"satchmo",

"scat",

"schwartza",

"schwarzenigger",

"schwarzie",

"schwoogie",

"semi-simian",

"shade",

"shadow",

"shadow-smurf",

"shaft",

"shaka zulu",

"shine/shiner",

"shipping cargo",

"shit-slinger",

"shitheel",

"shitskin",

"shoe shiner",

"shuffalong",

"shvartz",

"shvatsa",

"shvooga",

"silverback",

"silvery",

"simian",

"sir mix a lot",

"six",

"sixer",

"skillet",

"skinflint",

"slave",

"slave ships",

"sleestack",

"slide",

"smigger",

"smoke",

"smoked irish",

"smokefoot",

"smokestack",

"smokey",

"sneakers",

"snigger",

"snipes",

"snob",

"snowflake",

"son",

"sooty",

"soul food",

"southern windchime",

"spabook",

"used by michael jackson",
"spade",

"spear-chucker",

"splib",

"spliv",

"spoda",

"sponge head",

"spook",

"spoon",

"spoonbill",

"spota",

"stacks",

"stepn fetchit",

"stovelid",

"stovepipe",

"strange fruit",

"strap hangers",

"street cheetah",

"sub-human",

"suntan",

"suspect",

"swamp donkey",

"swamp-runner",

"swamper",

"sway",

"sweaty",

"sweetback",

"swinger",

"tagger",

"tar baby",

"ted stevens",

"terrence",

"the element",

"the missing link",

"thick lips",

"thief",

"thing-a-manigger",

"thirty-six-thirty (36-30)",

"three-fifth (3/5)",

"thumper",

"tibbs",

"tifuti",

"tigger",

"tizzun",

"toad",

"toby",

"toilet swimmer",

"token",

"tokenbump",

"tom robinson",

"tootsie rolls",

"tounge-clicker",

"tree hockey",

"tree ornament",

"tree-jumper",

"tree-swinger",

"trigger",

"tripod",

"tutsoon/tootsoon",

"tycoon",

"tyrone",

"tyvek",

"ubangi",

"uncle ben",

"uncle tom",

"unemployus africanus",

"urkel",

"vacuum cleaner",

"vanilla coke",

"vanilla gorilla",

"velcro-head",

"vinny del",

"voodoo",

"water buffalo",

"watermelon",

"wayans",

"webe",

"welfare monkey",

"welfare mother",

"whale turd",

"whipping post",

"white wall",

"whose my daddy?",

"wikki wikki",

"windchimes",

"wog",

"golliwogg, a stuffed doll that mimicked blacks. recently was dropped",

"wookie",

"wool head",

"yam",

"yard ape",

"ybm",

"yen",

"yo yo",

"yom",

"yombo",

"yont'an saram",

"you people",

"ze goggles",

"zigaboo",

"zip coon",

"zoo ape",

"zoot",

"zulu",

"willy b.",

"tnb",
]

export const jewishKw = [
"10% off",

"539",

"amf",

"bagel-dog",

"bar code",

"beanie",

"beastie boy",

"bible-shortener",

"big nose",

"bones",

"brew",

"bronx indian",

"bun",

"burger",

"campers",

"canadian goose",

"cashew",

"christ killer",

"circle-k",

"cliptip",

"crikey",

"dead sea pedestrian",

"dial",

"dreidl",

"easy-bake nigger",

"falasha",

"firewood",

"four by two",

"gargamel",

"gatemaster",

"german candle",

"german oven mitt",

"gew",

"gingerbread man",

"goldberg",

"goldie",

"half-dick",

"hanah",

"hebe/heeb",

"hebro",

"hickory-smoked",

"himey",

"hooknose",

"horvitz",

"hot pocket",

"hymie",

"ikey-mo",

"interesting",

"isaac",

"jap",

"jesus killer",

"jew",

"jew jew bee",

"jew yorker",

"jew-bag",

"jewbacca",

"jewbling",

"jewbrew",

"jewbu",

"jewess",

"jewgaboo",

"jewlet",

"jewmaican",

"jewpac",

"jewpidity",

"jubu",

"kike",

"kosher konsumer",

"koshie",

"lamp shade",

"matza-gobbler",

"matzah",

"mockey",

"morta cristo",

"moses",

"mosquito",

"nickel nose",

"oven magnet",

"oven-baked",

"oven-dweller",

"palm beacher",

"penny chaser",

"penny-pincher",

"pinocchio",

"pizza",

"popular science",

"porky",

"red sea pedestrian",

"scooby doo",

"seinfeld",

"self-chosen",

"sheeny",

"sheister",

"shnozzle",

"shonnicker",

"shylock",

"six point(er)",

"six-nose",

"snipcock",

"snow bird",

"snowflake",

"special meal",

"stein",

"toucan sam",

"wandering jew",

"wej",

"yahoodi",

"yenta",

"yid",

"yid/yid-lid",

"yiddiot",

"yitze",

"yom",

"zhid",

"zhidan",

"zionist",

"zog",
]

export const whiteKw = [
"10% off",

"539",

"amf",

"bagel-dog",

"bar code",

"beanie",

"beastie boy",

"bible-shortener",

"big nose",

"bones",

"brew",

"bronx indian",

"bun",

"burger",

"campers",

"canadian goose",

"cashew",

"christ killer",

"circle-k",

"cliptip",

"crikey",

"dead sea pedestrian",

"dial",

"dreidl",

"easy-bake nigger",

"falasha",

"firewood",

"four by two",

"gargamel",

"gatemaster",

"german candle",

"german oven mitt",

"gew",

"gingerbread man",

"goldberg",

"goldie",

"half-dick",

"hanah",

"hebe/heeb",

"hebro",

"hickory-smoked",

"himey",

"hooknose",

"horvitz",

"hot pocket",

"hymie",

"ikey-mo",

"interesting",

"isaac",

"jap",

"jesus killer",

"jew",

"jew jew bee",

"jew yorker",

"jew-bag",

"jewbacca",

"jewbling",

"jewbrew",

"jewbu",

"jewess",

"jewgaboo",

"jewlet",

"jewmaican",

"jewpac",

"jewpidity",

"jubu",

"kike",

"kosher konsumer",

"koshie",

"lamp shade",

"matza-gobbler",

"matzah",

"mockey",

"morta cristo",

"moses",

"mosquito",

"nickel nose",

"oven magnet",

"oven-baked",

"oven-dweller",

"palm beacher",

"penny chaser",

"penny-pincher",

"pinocchio",

"pizza",

"popular science",

"porky",

"red sea pedestrian",

"scooby doo",

"seinfeld",

"self-chosen",

"sheeny",

"sheister",

"shnozzle",

"shonnicker",

"shylock",

"six point(er)",

"six-nose",

"snipcock",

"snow bird",

"snowflake",

"special meal",

"stein",

"toucan sam",

"wandering jew",

"wej",

"yahoodi",

"yenta",

"yid",

"yid/yid-lid",

"yiddiot",

"yitze",

"yom",

"zhid",

"zhidan",

"zionist",

"zog",
]

export const latinxKw = [
"10% off",

"539",

"amf",

"bagel-dog",

"bar code",

"beanie",

"beastie boy",

"bible-shortener",

"big nose",

"bones",

"brew",

"bronx indian",

"bun",

"burger",

"campers",

"canadian goose",

"cashew",

"christ killer",

"circle-k",

"cliptip",

"crikey",

"dead sea pedestrian",

"dial",

"dreidl",

"easy-bake nigger",

"falasha",

"firewood",

"four by two",

"gargamel",

"gatemaster",

"german candle",

"german oven mitt",

"gew",

"gingerbread man",

"goldberg",

"goldie",

"half-dick",

"hanah",

"hebe/heeb",

"hebro",

"hickory-smoked",

"himey",

"hooknose",

"horvitz",

"hot pocket",

"hymie",

"ikey-mo",

"interesting",

"isaac",

"jap",

"jesus killer",

"jew",

"jew jew bee",

"jew yorker",

"jew-bag",

"jewbacca",

"jewbling",

"jewbrew",

"jewbu",

"jewess",

"jewgaboo",

"jewlet",

"jewmaican",

"jewpac",

"jewpidity",

"jubu",

"kike",

"kosher konsumer",

"koshie",

"lamp shade",

"matza-gobbler",

"matzah",

"mockey",

"morta cristo",

"moses",

"mosquito",

"nickel nose",

"oven magnet",

"oven-baked",

"oven-dweller",

"palm beacher",

"penny chaser",

"penny-pincher",

"pinocchio",

"pizza",

"popular science",

"porky",

"red sea pedestrian",

"scooby doo",

"seinfeld",

"self-chosen",

"sheeny",

"sheister",

"shnozzle",

"shonnicker",

"shylock",

"six point(er)",

"six-nose",

"snipcock",

"snow bird",

"snowflake",

"special meal",

"stein",

"toucan sam",

"wandering jew",

"wej",

"yahoodi",

"yenta",

"yid",

"yid/yid-lid",

"yiddiot",

"yitze",

"yom",

"zhid",

"zhidan",

"zionist",

"zog",
]
export const lgbtqKw = [
"10% off",

"539",

"amf",

"bagel-dog",

"bar code",

"beanie",

"beastie boy",

"bible-shortener",

"big nose",

"bones",

"brew",

"bronx indian",

"bun",

"burger",

"campers",

"canadian goose",

"cashew",

"christ killer",

"circle-k",

"cliptip",

"crikey",

"dead sea pedestrian",

"dial",

"dreidl",

"easy-bake nigger",

"falasha",

"firewood",

"four by two",

"gargamel",

"gatemaster",

"german candle",

"german oven mitt",

"gew",

"gingerbread man",

"goldberg",

"goldie",

"half-dick",

"hanah",

"hebe/heeb",

"hebro",

"hickory-smoked",

"himey",

"hooknose",

"horvitz",

"hot pocket",

"hymie",

"ikey-mo",

"interesting",

"isaac",

"jap",

"jesus killer",

"jew",

"jew jew bee",

"jew yorker",

"jew-bag",

"jewbacca",

"jewbling",

"jewbrew",

"jewbu",

"jewess",

"jewgaboo",

"jewlet",

"jewmaican",

"jewpac",

"jewpidity",

"jubu",

"kike",

"kosher konsumer",

"koshie",

"lamp shade",

"matza-gobbler",

"matzah",

"mockey",

"morta cristo",

"moses",

"mosquito",

"nickel nose",

"oven magnet",

"oven-baked",

"oven-dweller",

"palm beacher",

"penny chaser",

"penny-pincher",

"pinocchio",

"pizza",

"popular science",

"porky",

"red sea pedestrian",

"scooby doo",

"seinfeld",

"self-chosen",

"sheeny",

"sheister",

"shnozzle",

"shonnicker",

"shylock",

"six point(er)",

"six-nose",

"snipcock",

"snow bird",

"snowflake",

"special meal",

"stein",

"toucan sam",

"wandering jew",

"wej",

"yahoodi",

"yenta",

"yid",

"yid/yid-lid",

"yiddiot",

"yitze",

"yom",

"zhid",

"zhidan",

"zionist",

"zog",
]
export const muslimKw = [
"10% off",

"539",

"amf",

"bagel-dog",

"bar code",

"beanie",

"beastie boy",

"bible-shortener",

"big nose",

"bones",

"brew",

"bronx indian",

"bun",

"burger",

"campers",

"canadian goose",

"cashew",

"christ killer",

"circle-k",

"cliptip",

"crikey",

"dead sea pedestrian",

"dial",

"dreidl",

"easy-bake nigger",

"falasha",

"firewood",

"four by two",

"gargamel",

"gatemaster",

"german candle",

"german oven mitt",

"gew",

"gingerbread man",

"goldberg",

"goldie",

"half-dick",

"hanah",

"hebe/heeb",

"hebro",

"hickory-smoked",

"himey",

"hooknose",

"horvitz",

"hot pocket",

"hymie",

"ikey-mo",

"interesting",

"isaac",

"jap",

"jesus killer",

"jew",

"jew jew bee",

"jew yorker",

"jew-bag",

"jewbacca",

"jewbling",

"jewbrew",

"jewbu",

"jewess",

"jewgaboo",

"jewlet",

"jewmaican",

"jewpac",

"jewpidity",

"jubu",

"kike",

"kosher konsumer",

"koshie",

"lamp shade",

"matza-gobbler",

"matzah",

"mockey",

"morta cristo",

"moses",

"mosquito",

"nickel nose",

"oven magnet",

"oven-baked",

"oven-dweller",

"palm beacher",

"penny chaser",

"penny-pincher",

"pinocchio",

"pizza",

"popular science",

"porky",

"red sea pedestrian",

"scooby doo",

"seinfeld",

"self-chosen",

"sheeny",

"sheister",

"shnozzle",

"shonnicker",

"shylock",

"six point(er)",

"six-nose",

"snipcock",

"snow bird",

"snowflake",

"special meal",

"stein",

"toucan sam",

"wandering jew",

"wej",

"yahoodi",

"yenta",

"yid",

"yid/yid-lid",

"yiddiot",

"yitze",

"yom",

"zhid",

"zhidan",

"zionist",

"zog",
]